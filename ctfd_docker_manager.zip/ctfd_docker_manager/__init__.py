from flask import Blueprint
from CTFd.plugins import register_plugin_assets_directory
from CTFd.plugins.flags import get_flag_class
from CTFd.models import db
from .models import DockerContainer, DockerHost, ChallengeContainer
from .views import docker_admin, docker_api
from .config import DockerConfig
# from flask_wtf.csrf import CSRFProtect
# from .csrf_utils import csrf

def load(app):
    """
    Called by CTFd to load the plugin
    """
    # csrf.init_app(app)
    # Create database tables
    app.db.create_all()
    
    # Register plugin assets
    register_plugin_assets_directory(
        app, base_path="/plugins/ctfd_docker_manager/assets/"
    )
    
    # Register blueprints
    app.register_blueprint(docker_admin)
    app.register_blueprint(docker_api)
    
    # Initialize Docker configuration
    DockerConfig.init_app(app)
    
    print("CTFd Docker Manager Plugin Loaded Successfully!")



# def load(app):
#     @app.route('/plugins/test')
#     def test():
#         return "✅ Plugin route working!"
