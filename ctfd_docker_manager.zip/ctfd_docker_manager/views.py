from flask import Blueprint, request, jsonify, flash, redirect, url_for, render_template
from CTFd.utils.decorators import admins_only
from CTFd.models import db, Challenges
from CTFd.utils.security.signing import generate_nonce, validate_nonce
from .models import DockerHost, DockerContainer, ChallengeContainer
from .docker_manager import DockerManager
import json
from datetime import datetime
from CTFd.utils.user import get_current_user, is_admin
import os
# from CTFd.plugins.ctfd_docker_manager.csrf_utils import csrf_exempt


plugin_dir = os.path.dirname(os.path.realpath(__file__))
# Create blueprints
docker_admin = Blueprint('docker_admin', __name__, template_folder=os.path.join(plugin_dir, 'templates'), url_prefix='/admin/docker')
docker_api = Blueprint('docker_api', __name__, url_prefix='/api/docker')

@docker_admin.route('/')
@admins_only
def dashboard():
    """Docker management dashboard"""
    # Get statistics
    hosts = DockerHost.query.filter_by(is_active=True).all()
    containers = DockerContainer.query.all()
    challenge_containers = ChallengeContainer.query.all()
    
    stats = {
        'total_hosts': len(hosts),
        'total_containers': len(containers),
        'running_containers': len([c for c in containers if c.status == 'running']),
        'challenge_mappings': len(challenge_containers)
    }
    
    return render_template('docker_manager/docker_dashboard.html', 
                         hosts=hosts, 
                         containers=containers[:10],  # Show recent 10
                         stats=stats)

@docker_admin.route('/hosts')
@admins_only
def hosts():
    """Manage Docker hosts"""
    hosts = DockerHost.query.all()
    return render_template('docker_manager/docker_hosts.html', hosts=hosts)

# @docker_admin.route('/hosts/add', methods=['GET', 'POST'])
# @admins_only
# def add_host():
#     user = get_current_user()
#     print(f"[DEBUG] Current user: {user.name}, is_admin={is_admin()}")
#     if request.method == 'POST':
#         nonce = request.form.get("nonce")
#         print(nonce)
#         if not validate_nonce(nonce, "add_docker_host"):
#             flash("Invalid CSRF token", "error")
#             return render_template('add_docker_host.html', nonce=generate_nonce(16, "add_docker_host"))

#         try:
#             host = DockerHost(
#                 name=request.form['name'],
#                 host=request.form['host'],
#                 tls_enabled=bool(request.form.get('tls_enabled')),
#                 cert_path=request.form.get('cert_path'),
#                 key_path=request.form.get('key_path'),
#                 ca_path=request.form.get('ca_path')
#             )

#             # Test connection
#             manager = DockerManager(host)
#             info = manager.get_host_info()
#             if 'error' in info:
#                 flash(f'Connection failed: {info["error"]}', 'error')
#                 return render_template('add_docker_host.html', nonce=generate_nonce(16, "add_docker_host"))

#             db.session.add(host)
#             db.session.commit()
#             flash(f'Docker host "{host.name}" added successfully!', 'success')
#             return redirect(url_for('docker_admin.hosts'))

#         except Exception as e:
#             flash(f'Error adding host: {str(e)}', 'error')
#             return render_template('add_docker_host.html', nonce=generate_nonce(16, "add_docker_host"))

#     # GET request
#     return render_template('add_docker_host.html', nonce=generate_nonce(16, "add_docker_host"))
@docker_admin.route("/hosts/add", methods=["GET", "POST"])
@admins_only
def add_host():
    print("start")
    if request.method == "POST":
        nonce = request.form.get("nonce")
        print(nonce)
        # Optionally validate nonce here if needed

        name = request.form.get("name")
        ip_address = request.form.get("ip_address")

        # Save to DB (simplified, add validation as needed)
        host = DockerHost(name=name, ip_address=ip_address)
        db.session.add(host)
        db.session.commit()

        return redirect(url_for("docker_admin.list_hosts"))

    # ✅ Pass nonce to template here
    nonce = generate_nonce()
    return render_template("docker_manager/add_docker_host.html", nonce=nonce)

@docker_admin.route('/containers')
@admins_only
def containers():
    """Manage containers"""
    containers = DockerContainer.query.order_by(DockerContainer.created_at.desc()).all()
    hosts = DockerHost.query.filter_by(is_active=True).all()
    return render_template('docker_manager/docker_containers.html', containers=containers, hosts=hosts)

@docker_admin.route('/containers/deploy', methods=['GET', 'POST'])
@admins_only
def deploy_container():
    """Deploy new container"""
    if request.method == 'POST':
        try:
            # Parse form data
            ports = {}
            environment = {}
            volumes = {}
            
            # Parse ports (format: "host_port:container_port")
            if request.form.get('ports'):
                for port_mapping in request.form['ports'].split(','):
                    if ':' in port_mapping:
                        host_port, container_port = port_mapping.strip().split(':')
                        ports[container_port] = host_port
            
            # Parse environment variables (format: "KEY=value")
            if request.form.get('environment'):
                for env_var in request.form['environment'].split(','):
                    if '=' in env_var:
                        key, value = env_var.strip().split('=', 1)
                        environment[key] = value
            
            # Create container record
            container = DockerContainer(
                name=request.form['name'],
                image=request.form['image'],
                host_id=int(request.form['host_id']),
                ports=json.dumps(ports),
                environment=json.dumps(environment),
                volumes=json.dumps(volumes),
                memory_limit=request.form.get('memory_limit'),
                cpu_limit=request.form.get('cpu_limit'),
                challenge_id=int(request.form['challenge_id']) if request.form.get('challenge_id') else None
            )
            
            db.session.add(container)
            db.session.flush()  # Get the ID
            
            # Deploy container
            host = DockerHost.query.get(container.host_id)
            manager = DockerManager(host)
            success, message = manager.deploy_container(container)
            
            if success:
                db.session.commit()
                flash(f'Container "{container.name}" deployed successfully!', 'success')
            else:
                db.session.rollback()
                flash(f'Deployment failed: {message}', 'error')
                return render_template('docker_manager/deploy_container.html', 
                                     hosts=DockerHost.query.filter_by(is_active=True).all(),
                                     challenges=Challenges.query.all())
            
            return redirect(url_for('docker_admin.containers'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error deploying container: {str(e)}', 'error')
    
    hosts = DockerHost.query.filter_by(is_active=True).all()
    challenges = Challenges.query.all()
    return render_template('docker_manager/deploy_container.html', hosts=hosts, challenges=challenges)

@docker_admin.route('/challenges')
@admins_only
def challenges():
    """Manage challenge-container mappings"""
    challenge_containers = ChallengeContainer.query.all()
    challenges = Challenges.query.all()
    return render_template('challenge_containers.html', 
                         challenge_containers=challenge_containers,
                         challenges=challenges)

# API Routes
@docker_api.route('/containers/<int:container_id>/start', methods=['POST'])
# @csrf_exempt
@admins_only
def start_container(container_id):
    """Start a container"""
    try:
        container = DockerContainer.query.get_or_404(container_id)
        manager = DockerManager(container.host)
        
        if container.status == 'stopped':
            # Restart existing container
            docker_container = manager.client.containers.get(container.container_id)
            docker_container.start()
            container.status = 'running'
            container.started_at = datetime.utcnow()
        else:
            # Deploy new container
            success, message = manager.deploy_container(container)
            if not success:
                return jsonify({'success': False, 'message': message}), 400
        
        db.session.commit()
        return jsonify({'success': True, 'message': 'Container started successfully'})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@docker_api.route('/containers/<int:container_id>/stop', methods=['POST'])
# @csrf_exempt
@admins_only
def stop_container(container_id):
    """Stop a container"""
    try:
        container = DockerContainer.query.get_or_404(container_id)
        manager = DockerManager(container.host)
        
        success, message = manager.stop_container(container)
        if success:
            db.session.commit()
            return jsonify({'success': True, 'message': message})
        else:
            return jsonify({'success': False, 'message': message}), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@docker_api.route('/containers/<int:container_id>/remove', methods=['DELETE'])
# @csrf_exempt
@admins_only
def remove_container(container_id):
    """Remove a container"""
    try:
        container = DockerContainer.query.get_or_404(container_id)
        manager = DockerManager(container.host)
        
        success, message = manager.remove_container(container)
        if success:
            db.session.delete(container)
            db.session.commit()
            return jsonify({'success': True, 'message': message})
        else:
            return jsonify({'success': False, 'message': message}), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@docker_api.route('/containers/<int:container_id>/stats')
@admins_only
def container_stats(container_id):
    """Get container statistics"""
    try:
        container = DockerContainer.query.get_or_404(container_id)
        if container.status != 'running' or not container.container_id:
            return jsonify({'error': 'Container not running'}), 400
        
        manager = DockerManager(container.host)
        stats = manager.get_container_stats(container.container_id)
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@docker_api.route('/hosts/<int:host_id>/info')
@admins_only
def host_info(host_id):
    """Get Docker host information"""
    try:
        host = DockerHost.query.get_or_404(host_id)
        manager = DockerManager(host)
        info = manager.get_host_info()
        
        return jsonify(info)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@docker_api.route('/hosts/<int:host_id>/containers')
@admins_only
def host_containers(host_id):
    """List containers on a specific host"""
    try:
        host = DockerHost.query.get_or_404(host_id)
        manager = DockerManager(host)
        containers = manager.list_containers()
        
        return jsonify(containers)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500