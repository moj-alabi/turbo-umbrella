// CTFd Docker Manager JavaScript

// Global variables
let refreshInterval = null;
let statsInterval = null;

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', function() {
    initializeDockerManager();
});

function initializeDockerManager() {
    // Add active class to current navigation item
    highlightCurrentNav();
    
    // Initialize auto-refresh for dashboard
    if (window.location.pathname.includes('/admin/docker/')) {
        startAutoRefresh();
    }
    
    // Initialize tooltips if Bootstrap is available
    if (typeof bootstrap !== 'undefined') {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

function highlightCurrentNav() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.docker-menu .nav-link');
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });
}

function startAutoRefresh() {
    // Refresh every 30 seconds
    refreshInterval = setInterval(() => {
        if (window.location.pathname.includes('/admin/docker/')) {
            refreshDashboardData();
        }
    }, 30000);
}

function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

function refreshDashboardData() {
    // Only refresh if we're still on a Docker management page
    if (!window.location.pathname.includes('/admin/docker/')) {
        stopAutoRefresh();
        return;
    }
    
    // Refresh container statuses
    const containerRows = document.querySelectorAll('[id^="container-"]');
    containerRows.forEach(row => {
        const containerId = row.id.replace('container-', '');
        updateContainerStatus(containerId);
    });
    
    // Refresh host statuses
    const hostElements = document.querySelectorAll('[data-host-id]');
    hostElements.forEach(element => {
        const hostId = element.getAttribute('data-host-id');
        updateHostStatus(hostId);
    });
}

function updateContainerStatus(containerId) {
    // This would typically make an API call to get updated status
    // For now, we'll just add a visual indicator that data is being refreshed
    const row = document.getElementById(`container-${containerId}`);
    if (row) {
        row.classList.add('refreshing');
        setTimeout(() => {
            row.classList.remove('refreshing');
        }, 1000);
    }
}

function updateHostStatus(hostId) {
    fetch(`/api/docker/hosts/${hostId}/info`)
        .then(response => response.json())
        .then(data => {
            const hostElement = document.querySelector(`[data-host-id="${hostId}"]`);
            if (hostElement) {
                const statusElement = hostElement.querySelector('.status-indicator');
                const infoElement = hostElement.querySelector('.host-info');
                
                if (data.error) {
                    statusElement.className = 'badge badge-danger status-indicator';
                    statusElement.innerHTML = '<i class="fas fa-circle"></i> Offline';
                    if (infoElement) {
                        infoElement.innerHTML = `<small class="text-danger">${data.error}</small>`;
                    }
                } else {
                    statusElement.className = 'badge badge-success status-indicator';
                    statusElement.innerHTML = '<i class="fas fa-circle"></i> Online';
                    if (infoElement) {
                        infoElement.innerHTML = `
                            <small class="text-muted">
                                Version: ${data.version}<br>
                                Containers: ${data.containers}<br>
                                Images: ${data.images}
                            </small>
                        `;
                    }
                }
            }
        })
        .catch(error => {
            console.error('Error updating host status:', error);
        });
}

// Container management functions
function startContainer(containerId) {
    if (confirm('Are you sure you want to start this container?')) {
        showLoadingState(`container-${containerId}`);
        
        fetch(`/api/docker/containers/${containerId}/start`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            hideLoadingState(`container-${containerId}`);
            
            if (data.success) {
                showNotification('success', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', data.message);
            }
        })
        .catch(error => {
            hideLoadingState(`container-${containerId}`);
            console.error('Error:', error);
            showNotification('error', 'An error occurred while starting the container');
        });
    }
}

function stopContainer(containerId) {
    if (confirm('Are you sure you want to stop this container?')) {
        showLoadingState(`container-${containerId}`);
        
        fetch(`/api/docker/containers/${containerId}/stop`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            hideLoadingState(`container-${containerId}`);
            
            if (data.success) {
                showNotification('success', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', data.message);
            }
        })
        .catch(error => {
            hideLoadingState(`container-${containerId}`);
            console.error('Error:', error);
            showNotification('error', 'An error occurred while stopping the container');
        });
    }
}

function removeContainer(containerId) {
    if (confirm('Are you sure you want to remove this container? This action cannot be undone.')) {
        showLoadingState(`container-${containerId}`);
        
        fetch(`/api/docker/containers/${containerId}/remove`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            hideLoadingState(`container-${containerId}`);
            
            if (data.success) {
                showNotification('success', data.message);
                
                // Remove the row from the table
                const row = document.getElementById(`container-${containerId}`);
                if (row) {
                    row.style.transition = 'opacity 0.3s';
                    row.style.opacity = '0';
                    setTimeout(() => {
                        row.remove();
                    }, 300);
                }
            } else {
                showNotification('error', data.message);
            }
        })
        .catch(error => {
            hideLoadingState(`container-${containerId}`);
            console.error('Error:', error);
            showNotification('error', 'An error occurred while removing the container');
        });
    }
}

// Utility functions
function showLoadingState(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.classList.add('loading');
    }
}

function hideLoadingState(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.classList.remove('loading');
    }
}

function showNotification(type, message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.style.minWidth = '300px';
    
    notification.innerHTML = `
        ${message}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close" onclick="this.parentElement.remove()">
            <span aria-hidden="true">&times;</span>
        </button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) {
        return `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else {
        return `${minutes}m`;
    }
}

// Real-time stats functions
function startStatsMonitoring(containerId) {
    if (statsInterval) {
        clearInterval(statsInterval);
    }
    
    statsInterval = setInterval(() => {
        updateContainerStats(containerId);
    }, 5000); // Update every 5 seconds
}

function stopStatsMonitoring() {
    if (statsInterval) {
        clearInterval(statsInterval);
        statsInterval = null;
    }
}

function updateContainerStats(containerId) {
    fetch(`/api/docker/containers/${containerId}/stats`)
        .then(response => response.json())
        .then(data => {
            if (!data.error) {
                updateStatsDisplay(data);
            }
        })
        .catch(error => {
            console.error('Error updating stats:', error);
        });
}

function updateStatsDisplay(stats) {
    // Update CPU usage
    const cpuElement = document.getElementById('cpu-usage');
    if (cpuElement) {
        cpuElement.textContent = `${stats.cpu_percent}%`;
        const cpuBar = document.getElementById('cpu-progress');
        if (cpuBar) {
            cpuBar.style.width = `${stats.cpu_percent}%`;
        }
    }
    
    // Update memory usage
    const memoryElement = document.getElementById('memory-usage');
    if (memoryElement) {
        memoryElement.textContent = `${stats.memory_percent.toFixed(1)}%`;
        const memoryBar = document.getElementById('memory-progress');
        if (memoryBar) {
            memoryBar.style.width = `${stats.memory_percent}%`;
        }
    }
    
    // Update network stats
    const networkRxElement = document.getElementById('network-rx');
    if (networkRxElement) {
        networkRxElement.textContent = formatBytes(stats.network_rx);
    }
    
    const networkTxElement = document.getElementById('network-tx');
    if (networkTxElement) {
        networkTxElement.textContent = formatBytes(stats.network_tx);
    }
}

// Clean up when leaving the page
window.addEventListener('beforeunload', function() {
    stopAutoRefresh();
    stopStatsMonitoring();
});