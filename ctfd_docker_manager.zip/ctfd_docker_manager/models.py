from CTFd.models import db
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime

class DockerHost(db.Model):
    __tablename__ = 'docker_hosts'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    host = Column(String(255), nullable=False)  # e.g., "tcp://192.168.1.100:2376" or "unix:///var/run/docker.sock"
    tls_enabled = Column(Boolean, default=False)
    cert_path = Column(String(255), nullable=True)
    key_path = Column(String(255), nullable=True)
    ca_path = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    containers = relationship("DockerContainer", back_populates="host")

class DockerContainer(db.Model):
    __tablename__ = 'docker_containers'
    
    id = Column(Integer, primary_key=True)
    container_id = Column(String(64), nullable=True)  # Docker container ID
    name = Column(String(100), nullable=False)
    image = Column(String(255), nullable=False)
    status = Column(String(20), default='created')  # created, running, stopped, removed
    ports = Column(Text, nullable=True)  # JSON string of port mappings
    environment = Column(Text, nullable=True)  # JSON string of env vars
    volumes = Column(Text, nullable=True)  # JSON string of volume mappings
    
    # Host relationship
    host_id = Column(Integer, ForeignKey('docker_hosts.id'), nullable=False)
    host = relationship("DockerHost", back_populates="containers")
    
    # Challenge relationship
    challenge_id = Column(Integer, ForeignKey('challenges.id'), nullable=True)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime, nullable=True)
    stopped_at = Column(DateTime, nullable=True)
    
    # Resource limits
    memory_limit = Column(String(20), nullable=True)  # e.g., "512m", "1g"
    cpu_limit = Column(String(20), nullable=True)     # e.g., "0.5", "1.0"

class ChallengeContainer(db.Model):
    __tablename__ = 'challenge_containers'
    
    id = Column(Integer, primary_key=True)
    challenge_id = Column(Integer, ForeignKey('challenges.id'), nullable=False)
    docker_image = Column(String(255), nullable=False)
    default_ports = Column(Text, nullable=True)  # JSON string
    default_environment = Column(Text, nullable=True)  # JSON string
    default_volumes = Column(Text, nullable=True)  # JSON string
    auto_deploy = Column(Boolean, default=False)
    max_instances = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)